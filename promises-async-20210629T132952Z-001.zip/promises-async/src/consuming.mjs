import setText, {appendText, showWaiting, hideWaiting} from "./results.mjs";

export function get() {
}

export function getCatch() {
}

export function chain() {
}

export function chainCatch() {
}

export function final() {
}