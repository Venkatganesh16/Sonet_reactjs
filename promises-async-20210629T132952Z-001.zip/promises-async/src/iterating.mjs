import setText , {appendText} from './results.mjs';

export function get(){
}

export function getCatch(){
}

export function chain(){
}

export function concurrent(){
}

export function parallel(){
}